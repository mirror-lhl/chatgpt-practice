const http = require('http');
const { createReadStream } = require('fs');
const { pipeline } = require('stream');
const { promisify } = require('util');

const PORT = 9000;
const TARGET_URL = 'https://api.openai.com';

const server = http.createServer((clientReq, clientRes) => {
  const proxyReq = http.request({
    method: clientReq.method,
    headers: clientReq.headers,
    host: TARGET_URL,
    path: clientReq.url
  }, (proxyRes) => {
    clientRes.writeHead(proxyRes.statusCode, proxyRes.headers);
    // 这里使用管道流将代理响应流直接输出到客户端输出流中
    pipeline(proxyRes, clientRes, (err) => {
      if (err) {
        console.error('Pipeline error:', err.message);
        clientRes.end();
      }
    });
  });

  // 如果客户端请求包含请求体，在发送代理请求之前需要将请求体写入代理请求体中
  if (clientReq.method === 'POST' || clientReq.method === 'PUT') {
    pipeline(clientReq, proxyReq, (err) => {
      if (err) {
        console.error('Pipeline error:', err.message);
        proxyReq.abort();
        clientRes.end();
      }
    });
  } else {
    proxyReq.end();
  }

  proxyReq.on('error', (err) => {
    console.error('Proxy request error:', err.message);
    clientRes.writeHead(500);
    clientRes.end();
  });
});

server.listen(PORT, () => {
  console.log(`Proxy server is running at http://localhost:${PORT}`);
});